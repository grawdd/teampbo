package com.smkn40jakarta;

import com.smkn40jakarta.kendaraan.kendaraan;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {  
    String namaDepan = "AGASTYA ADRIAN";
    String namaBelakang = " SAHLONA";
    String kelas = "XI-RPL";
    String jurusan = "REKAYASA PERANGKAT LUNAK";
    String sekolah = "SMKN 40 Jakarta";
    int absen = 28;
    int usia = 16;
    String alamat ="Jl.Menteng Jaya";

    System.out.println("Nama        : "+namaDepan+""+namaBelakang);
    System.out.println("Kelas       : "+kelas+"");
    System.out.println("Jurusan     : "+jurusan+"");
    System.out.println("nama sekolah: "+sekolah+"");
    System.out.println("usia        : "+usia+"");
    System.out.println("No Urut     : "+absen+"");
    System.out.println("alamat      : "+alamat+"");
    System.out.println("        ");
    System.out.println("BERAPA JUMLAH BAN MOBIL?");
    System.out.println("BERAPA JUMLAH BAN MOTOR?");
    
    

    kendaraan.jumlahban();
    motor.jumlahban();
   
    }
}
