package com.smkn40jakarta;

public class motor {
    public static void jumlahban()
    {
        System.out.println("Jumlah ban motor ada 2 ");
    }
    
}
