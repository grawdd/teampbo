package com.smkn40jakarta.kendaraan;

public class kendaraan {
    public static void jumlahban()
    {
        System.out.println("Jumlah ban mobil ada 4 ");

    }
    
}
